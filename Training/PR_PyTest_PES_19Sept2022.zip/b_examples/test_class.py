def func(x):
    return x + 1


# using Test before the class name is important otherwise it would be skipped during pytest discovery process
class TestClass:
    # class CheckClass:
    def test_pass1_func(self):
        assert func(2) == 3
        print("Output is", func(2))

    def test_pass2_func(self):
        assert func(5) == 6


    def pass3_func_test(self):
        assert func(5) == 6

    # will not get collected as it's not starting with test_
    def pass4_func(self):
        assert func(5) == 6

    def test_fail1_func(self):
        assert func(5) == 8

    def test_fail2_func(self):
        assert func(2) == 9

# invoke it using
#  pytest .\test_class.py
#  pytest .\test_class.py -v
#  pytest .\test_class.py -v -s     (it will include print statements as well)
