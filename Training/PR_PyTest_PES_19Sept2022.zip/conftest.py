import pytest


@pytest.fixture()
def tasks_db():
    """Connect to db before tests, disconnect after"""
    # setup: start db
    print("\nRunning before the test tasks_db fixture")
    yield
    # Teardown: stop db
    print("\nRunning after the test tasks_db fixture")
