import pytest

# assertion for expected exceptions
# def test_zero_division():
#     with pytest.raises(ZeroDivisionError):
#         a = 1/1     # will result in failure if this is the only statement
#         # d = 5 / 2  # will not result in failure if some statement of this block raises the expected exception
#         # a = 1 / 0

def f():
    f()             # RecursionError: maximum recursion depth exceeded
    return 1

# def f():
#     return 1

# f()

def test_recursion_depth():
    with pytest.raises(RuntimeError) as exception_info:
        f()

    assert "maximum recursion" in str(exception_info.value)



