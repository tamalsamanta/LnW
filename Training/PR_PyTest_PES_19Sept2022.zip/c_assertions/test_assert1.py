def f():
    return 5


def test_fun():
    assert f() == 6

# on execution: assertion introspection details will be shown


def test_even():
    a = 8
    # a = 7
    assert a % 2 == 0, "value was odd, should be even"
