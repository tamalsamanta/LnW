def test_set_comparison():
    set1 = set("1308")
    set2 = set("8031")
    # set2 = set("8035")
    assert set1 == set2
