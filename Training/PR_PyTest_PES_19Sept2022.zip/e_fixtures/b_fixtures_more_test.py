import pytest

# scope="function" applicable for each function (default scope)


@pytest.fixture(scope="function")   # function is the default scope
def my_fixture():
    print("\nRunning before Test1")  # setup()
    yield
    print("\nRunning after Test1")  # teardown()


@pytest.fixture(name="second_fixture")  # function is the default scope
def another():
    print("\nRunning before Test2")  # setup()
    yield
    print("\nRunning after Test2")  # teardown()


# @pytest.fixture(name="third_fixture")
# def fixture_using_another_fixture(second_fixture):      # one fixture can use another fixture
#     print("\nRunning before Test3")  # setup()
#     yield
#     print("\nRunning after Test3")  # teardown()


# def test_add_to_cart(my_fixture):  # mentioned the fixture to be used with the help of method name
#     print("\nRunning test add to cart")
#
#
# def test_payments(second_fixture):  # mentioned the fixture to be used with the help of fixture name
#     print("\nRunning test payment")


# def test_shipment(third_fixture):   # one fixture can use another fixture
#     print("\nRunning test shipment")


# def test_another(my_fixture, second_fixture):   # T1, T2        T2, T1
# # def test_another(second_fixture, my_fixture):   # T2, T1        T1, T2
#     print("\nRunning with another setup")
