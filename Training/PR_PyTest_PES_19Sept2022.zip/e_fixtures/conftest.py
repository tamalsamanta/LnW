import pytest


@pytest.fixture(scope="function")
def setup():
    print("\nRunning before Test setup fixture")
    yield
    print("\nRunning after Test setup fixture")
