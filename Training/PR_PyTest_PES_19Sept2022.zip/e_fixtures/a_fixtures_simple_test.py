import pytest

# scope="function" applicable for each function (default scope)


@pytest.fixture(scope="function")   # function is the default scope
def my_fixture():
    print("\nRunning before Test1")  # setup()
    yield
    print("\nRunning after Test1")  # teardown()


@pytest.fixture(name="second_fixture")  # function is the default scope
def another():
    print("\nRunning before Test2")  # setup()
    yield
    print("\nRunning after Test2")  # teardown()


def test_add_to_cart(my_fixture):  # mentioned the fixture to be used with the help of method name
    print("\nRunning test add to cart")


def test_payments(second_fixture):  # mentioned the fixture to be used with the help of fixture name
    print("\nRunning test payment")