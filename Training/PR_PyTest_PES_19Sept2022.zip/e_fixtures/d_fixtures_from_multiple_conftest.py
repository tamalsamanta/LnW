
def test_using_fixture_from_conftest_tasks_db(tasks_db):
    print("\nThis is the test execution block which is using tasks_db")
    assert True


def test_using_fixture_from_conftest_setup(setup):
    print("\nThis is the test execution block which is using setup")
    assert True
