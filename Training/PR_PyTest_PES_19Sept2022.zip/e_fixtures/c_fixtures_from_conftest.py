

def test_using_fixture_from_conftest_setup(setup):
    print("\nThis is the test Execution block which is using setup fixture")
    assert True
