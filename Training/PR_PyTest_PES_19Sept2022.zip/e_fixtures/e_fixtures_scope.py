import pytest


@pytest.fixture(scope='function')       # default scope is function, so no need to mention
def func_scope():
    """Function scope fixture"""
    print("\nInside Function scope fixture before")
    yield
    print("\nInside Function scope fixture after")


@pytest.fixture(scope='module')
def mod_scope():
    """A module scope fixture"""
    print("\nInside module scope fixture before")
    yield
    print("\nInside module scope fixture after")


@pytest.fixture(scope='session')
def sess_scope():
    """A session scope fixture"""
    print("\nInside session scope fixture before")
    yield
    print("\nInside session scope fixture after")


@pytest.fixture(scope='class')
def class_scope():
    """A class scope fixture"""
    print("\nInside class scope fixture before")
    yield
    print("\nInside class scope fixture after")


def test_1(sess_scope, mod_scope, func_scope):
    """Test using session, module, and function scope fixtures"""
    print("\nInside test_1")


def test_2(sess_scope, mod_scope, func_scope):
    """Test using session, module, and function scope fixtures"""
    print("\nInside test_2")


@pytest.mark.usefixtures('class_scope')
class TestClass():
    """Demo class scope fixtures"""

    def test_3(self):
    # def test_3(self, func_scope):
        """Test using a class scope fixture"""
        print("\ninside test_3")


    def test_4(self, func_scope):
        """More fun with Multiple tests"""
        print("\ninside test_4")

