import sys

import pytest

def test_passing():
    assert (1, 2, 3) == (1, 2, 3)


def test_passing2():
    assert (2, 3, 1) == (2, 3, 1)

# # failing tests
def test_failing():
    assert (1, 2, 3) == (3, 2, 3)


@pytest.mark.xfail(reason="This is a negative test scenario")
def test_this_should_fail():
    assert False


@pytest.mark.xfail()            # I am expecting this test to fail
def test_this_should_fail2():
    assert False


@pytest.mark.xfail(reason="This is a new feature. Yet to be implemented")
def test_this_feature_is_unimplemented():
    assert False


# a test is expected to fail on windows platform (along with reason and platform check)
@pytest.mark.xfail(sys.platform == "win32", reason="This feature is not supported on windows")
def test_this_should_fail3():
    assert False


# xfail would be applicable unconditionally (reported as xpassed because of passing condition)
@pytest.mark.xfail(reason="This feature is not supported on linux")
def test_this_should_fail4():
    assert True


# xfail would be applicable when running on win32 platform (reported as xpassed because of passing condition)
@pytest.mark.xfail(sys.platform == "win32", reason="This feature is not supported on linux")
def test_this_should_fail5():
    assert True

# xfail would be applicable when running on linux platform, otherwise a normal test without xfail marker
@pytest.mark.xfail(sys.platform == "linux", reason="This feature is not supported on linux")
def test_this_should_fail6():
    assert False
