import sys

import pytest

abc = "Hi"


def test_passing():
    assert (1, 2, 3) == (1, 2, 3)


@pytest.mark.skip()
def test_passing1():
    assert (2, 3, 1) == (2, 3, 1)



@pytest.mark.skipif('abc == "Hi"')
def test_passing2():
    assert (2, 3, 1) == (2, 3, 1)


@pytest.mark.skipif('abc == "Hi"', reason="Required Welcome message not set")
def test_passing3():
    assert (2, 3, 1) == (2, 3, 1)
# note to print the reason: pytest -r .\a_markers1_skip_skipif_test.py


@pytest.mark.skipif(sys.version_info > (3, 9), reason="applicable for python version older than 3.9")
def test_passing4():
    assert (2, 3, 1) == (2, 3, 1)


@pytest.mark.skipif(sys.version_info > (3, 10), reason="applicable for python version older than 3.10")
def test_passing5():
    assert (2, 3, 1) == (2, 3, 1)


# @pytest.mark.skip()
# def test_failing():
#     assert (1, 2, 3) == (3, 2, 3)
#
#
# @pytest.mark.skip(reason="This test is not ready yet")
# def test_failing2():
#     assert (1, 2, 3) == (1, 2, 4)


@pytest.mark.skipif(sys.platform == "win32", reason="This test is applicable only for linux platform")
def test_failing2():
    assert (1, 2, 3) == (1, 2, 4)


@pytest.mark.skipif(sys.platform != "win32", reason="This test is applicable only for windows platform")
def test_windows_platform_specific_test():
    assert (1, 2, 3) == (1, 2, 3)


@pytest.mark.skipif(sys.platform == "linux" or sys.platform == "mac", reason="only for windows platform")
def test_skip_for_linux_mac():
    assert (1, 2, 3) == (1, 2, 3)


@pytest.mark.skipif(sys.platform != "linux", reason="this test is applicable only for linux platform")
def test_linux_platform_specific_test():
    assert (1, 2, 3) == (1, 2, 3)
