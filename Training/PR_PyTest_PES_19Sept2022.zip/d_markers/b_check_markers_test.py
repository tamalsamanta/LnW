import pytest

@pytest.mark.skip()
def test_failing():
    assert (1, 2, 3) == (3, 2, 3)


@pytest.mark.skip(reason="This test is not ready yet")
def test_failing2():
    assert (1, 2, 3) == (1, 2, 4)
