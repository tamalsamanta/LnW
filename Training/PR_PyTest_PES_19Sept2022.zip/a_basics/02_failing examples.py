# # failing tests
def test_failing():
    assert (1, 2, 3) == (3, 2, 3)


def test_failing2():
    assert (1, 2, 3) == (1, 2, 4)


def test_failing3():
    assert (1, 2, 3) == (1, 4, 3)


def test_failing4():
    assert (1, 2, 3, 4) == (1, 4, 3)

