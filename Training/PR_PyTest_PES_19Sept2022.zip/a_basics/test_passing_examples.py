def test_passing():
    assert (1, 2, 3) == (1, 2, 3)
    print("This is passing test")

def test_passing2():
    assert (2, 3, 1) == (2, 3, 1)

# following two will not be discovered
def passing3():
    assert (2, 3, 1) == (2, 3, 1)
def passing4_test():
    assert (2, 3, 1) == (2, 3, 1)
