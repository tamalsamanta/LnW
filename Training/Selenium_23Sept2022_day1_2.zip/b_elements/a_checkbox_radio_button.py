import time

from selenium import webdriver

driver = webdriver.Chrome()
url = "http://cookbook.seleniumacademy.com/Config.html"

driver.get(url)     # visit the url
print(driver.title)

time.sleep(2)
element_airbags = driver.find_element(by="name", value="airbags")

if not element_airbags.is_selected():
    driver.find_element(by="name", value="airbags").click()

time.sleep(1)
# driver.find_element(by="name", value="fuel_type").click()

# driver.find_elements(by="name", value="fuel_type")[1].click()


time.sleep(2)

driver.quit()

