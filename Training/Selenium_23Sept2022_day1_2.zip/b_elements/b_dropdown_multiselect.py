import time

from selenium import webdriver
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome()
url = "http://cookbook.seleniumacademy.com/Config.html"

driver.get(url)     # visit the url
print(driver.title)
time.sleep(2)

# ------------------
make_element = driver.find_element(by="xpath", value="//select[@name='make']")
make = Select(make_element)  # pass the element of type select
make.select_by_value("audi")
time.sleep(2)
make.select_by_index(1)
time.sleep(2)
make.select_by_visible_text("Honda")

selected_option = make.first_selected_option
print(selected_option.text)




# ------------------
time.sleep(2)

driver.quit()

