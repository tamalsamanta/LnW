import time

from selenium import webdriver

driver = webdriver.Chrome()
url = "http://www.google.com"

driver.get(url)     # visit the url
assert driver.title == "Google", "Page title did not match"

element = driver.find_element(by="name", value="q")
element.send_keys("Selenium")

# element2 = driver.find_element(by="name", value="btnK")
# element2.submit()   # effect of enter key
# element2.click()

driver.find_element(by="name", value="btnK").submit()   # effect of enter key

time.sleep(2)
# back button
driver.back()
time.sleep(2)

driver.forward()
time.sleep(2)

driver.refresh()
time.sleep(2)

print(driver.current_url)

driver.minimize_window()
time.sleep(2)


driver.maximize_window()
time.sleep(2)


# cookies
print("All cookies", driver.get_cookies())
driver.delete_all_cookies()
print("All cookies", driver.get_cookies())

print("Page source", len(driver.page_source))

# window handle
count = len(driver.window_handles)
print(count)

print(driver.current_window_handle)

# driver.close()  # close current tab or current window
driver.quit() # close all instances of tab/ window opened by driver

