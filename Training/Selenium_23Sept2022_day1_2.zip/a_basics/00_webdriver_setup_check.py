from selenium import webdriver

# driver = webdriver.Chrome("../resources/chromedriver.exe")
driver = webdriver.Chrome()   # launch a fresh instance of the chrome browser
