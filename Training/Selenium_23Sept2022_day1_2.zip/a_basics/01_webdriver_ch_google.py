from selenium import webdriver

driver = webdriver.Chrome()
url = "http://www.google.com"

driver.get(url)     # visit the url
print(driver.title)

assert driver.title == "Google", "Page title did not match"

driver.close()
# driver.quit()

